/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 100406
 Source Host           : localhost:3306
 Source Schema         : programski_jezici_ispit

 Target Server Type    : MySQL
 Target Server Version : 100406
 File Encoding         : 65001

 Date: 25/06/2020 10:47:30
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for author
-- ----------------------------
DROP TABLE IF EXISTS `author`;
CREATE TABLE `author`  (
  `author_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `forename` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `surname` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `year_of_birth` int(20) UNSIGNED NOT NULL,
  PRIMARY KEY (`author_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of author
-- ----------------------------
INSERT INTO `author` VALUES (1, 'Ivo', 'Andric', 1892);
INSERT INTO `author` VALUES (2, 'Stiven', 'King', 1947);
INSERT INTO `author` VALUES (3, 'Milos', 'Crnjanski', 1893);
INSERT INTO `author` VALUES (4, 'Borisav', 'Stankovic', 1876);
INSERT INTO `author` VALUES (6, 'Piter', 'Straub', 1943);

-- ----------------------------
-- Table structure for book
-- ----------------------------
DROP TABLE IF EXISTS `book`;
CREATE TABLE `book`  (
  `book_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `publication_year` int(20) UNSIGNED NOT NULL,
  `number_of_pages` int(20) UNSIGNED NOT NULL,
  `price` int(10) UNSIGNED NOT NULL,
  `publisher` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`book_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 10 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of book
-- ----------------------------
INSERT INTO `book` VALUES (1, 'Seobe', 2015, 786, 1099, 'Laguna');
INSERT INTO `book` VALUES (2, 'Institut', 2020, 464, 1499, 'Vulkan');
INSERT INTO `book` VALUES (3, 'Na Drini cuprija', 2012, 376, 899, 'Laguna');
INSERT INTO `book` VALUES (4, 'Autsajder', 2019, 432, 1199, 'Vulkan');
INSERT INTO `book` VALUES (5, 'Dnevnik o Carnojevicu', 2017, 192, 799, 'Prometej');
INSERT INTO `book` VALUES (7, 'Prica o duhovima', 2005, 470, 1299, 'Vulkan');
INSERT INTO `book` VALUES (8, 'Talisman', 2013, 921, 1499, 'Vulkan');

-- ----------------------------
-- Table structure for book_author
-- ----------------------------
DROP TABLE IF EXISTS `book_author`;
CREATE TABLE `book_author`  (
  `book_author_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `book_id` int(10) UNSIGNED NOT NULL,
  `author_id` int(10) UNSIGNED NOT NULL,
  PRIMARY KEY (`book_author_id`) USING BTREE,
  INDEX `fk_book_author_book_id`(`book_id`) USING BTREE,
  INDEX `fk_book_author_author_id`(`author_id`) USING BTREE,
  CONSTRAINT `fk_book_author_author_id` FOREIGN KEY (`author_id`) REFERENCES `author` (`author_id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_book_author_book_id` FOREIGN KEY (`book_id`) REFERENCES `book` (`book_id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8 COLLATE = utf8_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of book_author
-- ----------------------------
INSERT INTO `book_author` VALUES (1, 1, 3);
INSERT INTO `book_author` VALUES (2, 2, 2);
INSERT INTO `book_author` VALUES (3, 3, 1);
INSERT INTO `book_author` VALUES (4, 4, 2);
INSERT INTO `book_author` VALUES (5, 7, 6);
INSERT INTO `book_author` VALUES (6, 8, 6);
INSERT INTO `book_author` VALUES (7, 8, 2);

SET FOREIGN_KEY_CHECKS = 1;
