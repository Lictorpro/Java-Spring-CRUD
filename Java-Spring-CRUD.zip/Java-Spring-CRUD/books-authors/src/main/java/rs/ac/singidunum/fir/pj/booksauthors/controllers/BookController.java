package rs.ac.singidunum.fir.pj.booksauthors.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import rs.ac.singidunum.fir.pj.booksauthors.entities.Author;
import rs.ac.singidunum.fir.pj.booksauthors.entities.Book;
import rs.ac.singidunum.fir.pj.booksauthors.repositories.BookRepository;

@RestController
public class BookController {
	
	@Autowired
	private BookRepository repository;
	
	@GetMapping("/books")
	public List<Book> getAllBooks(){
		return (List<Book>)repository.findAll();
	}
	
	@GetMapping("/books/{id}")
	public Book getBook(@PathVariable int id) {
		return repository.findById(id).orElse(null);
	}
	
	@PostMapping("/books")
	public Book addBook(@RequestBody Book book) {
		return repository.save(book);
	}
	
	@PutMapping("/books/{id}")
	public Book updateBook(@RequestBody Book book, @PathVariable int id) {
		return repository.save(book);
	}
	
	@DeleteMapping("/books/{id}")
	public void deleteBook(@PathVariable int id) {
		repository.deleteById(id);
	}
	
	@GetMapping("/books/count")
	public long getNumberOfBooks() {
		return repository.count();
	}
	
	@GetMapping("/books/search/title/{title}")
	public Book getBookByTitle(@PathVariable String title) {
		return repository.findByTitle(title);
	}
	
	@GetMapping("/books/author")
	public List<Book> getBooksByAuthor(@RequestBody Author author){
		return repository.findAllBooksByAuthors(author);
	}
	
	@GetMapping("/books/gt/{price}")
	public List<Book> getBooksGraterThanPrice(@PathVariable int price){
		return repository.findByPriceGreaterThanEqualOrderByPrice(price);
	}
	
	@GetMapping("/books/lt/{price}")
	public List<Book> getBooksLessThanPrice(@PathVariable int price){
		return repository.findByPriceLessThanEqualOrderByPrice(price);
	}
	
	@GetMapping("/books/search/publisher/{publisher}")
	public List<Book> getBooksByPublisher(@PathVariable String publisher) {
		return repository.findAllBooksByPublisher(publisher);
	}
	
	
}
