package rs.ac.singidunum.fir.pj.booksauthors.entities;

import java.util.Set;


import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity(name = "book")
public class Book {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int book_id;
	
	private String title;
	private int publication_year;
	private int number_of_pages;
	private int price;
	private String publisher;
	
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "book_author", 
	joinColumns = @JoinColumn(name = "book_id", referencedColumnName = "book_id"),
	inverseJoinColumns = @JoinColumn(name = "author_id", referencedColumnName = "author_id"))
	private Set<Author> authors;
	
	public Book(int book_id, String title, int publication_year, int number_of_pages, int price, String publisher) {
		this.book_id = book_id;
		this.title = title;
		this.publication_year = publication_year;
		this.number_of_pages = number_of_pages;
		this.price = price;
		this.publisher = publisher;
	}
	
	public Book() {
		
	}

	public int getBook_id() {
		return book_id;
	}

	public void setBook_id(int book_id) {
		this.book_id = book_id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public int getPublication_year() {
		return publication_year;
	}
	

	public void setPublication_year(int publication_year) {
		this.publication_year = publication_year;
	}

	public int getNumber_of_pages() {
		return number_of_pages;
	}

	public void setNumber_of_pages(int number_of_pages) {
		this.number_of_pages = number_of_pages;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}
	
	public String getPublisher() {
		return publisher;
	}
	
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	
	
	
	
	
}
