package rs.ac.singidunum.fir.pj.booksauthors.controllers;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import rs.ac.singidunum.fir.pj.booksauthors.entities.Author;
import rs.ac.singidunum.fir.pj.booksauthors.entities.Book;
import rs.ac.singidunum.fir.pj.booksauthors.repositories.AuthorRepository;

@RestController
public class AuthorController {
	
	@Autowired
	private AuthorRepository repository;
	
	@GetMapping("/authors")
	public List<Author> getAllAuthors(){
		return (List<Author>)repository.findAll();
	}
	
	@GetMapping("/authors/{id}")
	public Author getAuthor(@PathVariable int id) {
		return repository.findById(id).orElse(null);
	}
	
	@PostMapping("/authors")
	public Author addAuthor(@RequestBody Author author) {
		return repository.save(author);
	}
	
	@PutMapping("/authors/{id}")
	public Author updateAuthor(@RequestBody Author author, @PathVariable int id) {
		return repository.save(author);
	}
	
	@DeleteMapping("/authors/{id}")
	public void deleteAuthor(@PathVariable int id) {
		repository.deleteById(id);
	}
	
	@GetMapping("/authors/count")
	public long getNumberOfAuthors() {
		return repository.count();
	}
	
	@GetMapping("/authors/book")
	public List<Author> getAuthorsByBook(@RequestBody Book book){
		return repository.findAllAuthorsByBooks(book);
	}
}
