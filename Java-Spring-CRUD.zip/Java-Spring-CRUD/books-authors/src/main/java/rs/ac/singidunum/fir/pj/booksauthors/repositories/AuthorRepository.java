package rs.ac.singidunum.fir.pj.booksauthors.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import rs.ac.singidunum.fir.pj.booksauthors.entities.Author;
import rs.ac.singidunum.fir.pj.booksauthors.entities.Book;

public interface AuthorRepository extends CrudRepository<Author, Integer>{
	
	List<Author> findAllAuthorsByBooks(Book book);
}
