package rs.ac.singidunum.fir.pj.booksauthors.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import rs.ac.singidunum.fir.pj.booksauthors.entities.Author;
import rs.ac.singidunum.fir.pj.booksauthors.entities.Book;

public interface BookRepository extends CrudRepository<Book, Integer>{
	
	Book findByTitle(String title);
	List<Book> findAllBooksByAuthors(Author author);
	List<Book> findByPriceGreaterThanEqualOrderByPrice(int price);
	List<Book> findByPriceLessThanEqualOrderByPrice(int price);
	List<Book> findAllBooksByPublisher(String publisher);
}
