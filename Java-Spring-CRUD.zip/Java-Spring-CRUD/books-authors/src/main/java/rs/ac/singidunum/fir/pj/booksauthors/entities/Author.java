package rs.ac.singidunum.fir.pj.booksauthors.entities;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

@Entity(name = "author")
public class Author {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int author_id;
	private String forename;
	private String surname;
	private int year_of_birth;
	
	@ManyToMany(mappedBy = "authors")
	private Set<Book> books;
	
	public Author(int author_id, String forename, String surname, int year_of_birth) {
		this.author_id = author_id;
		this.forename = forename;
		this.surname = surname;
		this.year_of_birth = year_of_birth;
	}
	
	public Author() {
		
	}

	public int getAuthor_id() {
		return author_id;
	}

	public void setAuthor_id(int author_id) {
		this.author_id = author_id;
	}

	public String getForename() {
		return forename;
	}

	public void setForename(String forename) {
		this.forename = forename;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

	public int getYear_of_birth() {
		return year_of_birth;
	}

	public void setYear_of_birth(int year_of_birth) {
		this.year_of_birth = year_of_birth;
	}
	
	
	
	
	
}
