package rs.ac.singidunum.fir.pj.booksauthors;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BooksAuthorsApplicationTests {

	@Test
	void contextLoads() {
	}

}
